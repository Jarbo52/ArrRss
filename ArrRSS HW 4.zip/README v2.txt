Team Members: Jordan Guzman, Connor Murphy, Jacob Fallin, Jared Bass

We pledge our honor that we have abided by the Stevens Honor System.

About page contains all contributions. 

Please note: Most things the site does is done through JavaScript. As such, no functions such as RSS requests will work. 

Also, the site is designed with a desktop/laptop only use in mind, as most boxes are made that way. As such, to cover "responsiveness",
if the window becomes too small the entire page just whites out.

Not my best work but it's what we're going with at this phase in development. We will attend office hours to improve.
